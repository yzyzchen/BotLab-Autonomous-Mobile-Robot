README.txt

This library has been tested exclusively on the pico since serial communication is not yet working. However, this library 
has been developed with portability in mind. It should be simple to port this over to the RPI or any other C device.