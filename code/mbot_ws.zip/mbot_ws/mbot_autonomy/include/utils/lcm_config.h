#ifndef LCM_CONFIG_H
#define LCM_CONFIG_H

/////// Data channels //////

#define MULTICAST_URL "udpm://239.255.76.67:7667?ttl=0"

#define OLED_CHAN "OLED_MESSAGE"

#endif // LCM_CONFIG_H
