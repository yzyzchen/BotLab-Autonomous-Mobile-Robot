#ifndef BAROMETER_H
#define BAROMETER_H

void mbot_initialize_barometer();
double mbot_read_barometer_pressure();
double mbot_read_barometer_temperature();

#endif